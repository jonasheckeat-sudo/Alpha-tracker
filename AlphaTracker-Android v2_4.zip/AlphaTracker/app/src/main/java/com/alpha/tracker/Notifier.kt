package com.alpha.tracker

import android.app.*
import android.content.*
import android.os.Build
import java.util.Calendar

object Notifier {
    fun today(): String {
        val n = Calendar.getInstance()
        return String.format("%04d-%02d-%02d", n.get(Calendar.YEAR), n.get(Calendar.MONTH) + 1, n.get(Calendar.DAY_OF_MONTH))
    }

    private fun setAlarm(c: Context, ms: Long, pi: PendingIntent) {
        val am = c.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
    }

    fun show(c: Context, msg: String) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel("alpha", "Alpha Tracker", NotificationManager.IMPORTANCE_HIGH)
        ch.enableVibration(true); ch.vibrationPattern = longArrayOf(0, 200, 100, 200)
        nm.createNotificationChannel(ch)
        val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(1, Notification.Builder(c, "alpha").setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Alpha Tracker").setContentText(msg).setContentIntent(pi).setAutoCancel(true).build())
    }

    fun showWeekly(c: Context, text: String) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel("alpha_week", "Wochenbilanz", NotificationManager.IMPORTANCE_HIGH)
        ch.enableVibration(true); ch.vibrationPattern = longArrayOf(0, 60, 80, 60, 80, 300)
        nm.createNotificationChannel(ch)
        val i = Intent(c, MainActivity::class.java).putExtra("week", true)
        val pi = PendingIntent.getActivity(c, 5, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(2, Notification.Builder(c, "alpha_week").setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Deine Wochenbilanz").setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi).setAutoCancel(true).build())
    }

    fun schedule(c: Context) {
        val p = c.getSharedPreferences("a", 0)
        val pi = PendingIntent.getBroadcast(c, 1, Intent(c, AlarmReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        if (!p.getBoolean("rem", true)) { c.getSystemService(AlarmManager::class.java).cancel(pi); return }
        val hm = p.getString("time", "18:00")!!.split(":").map { it.toInt() }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hm[0]); set(Calendar.MINUTE, hm[1]); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        setAlarm(c, cal.timeInMillis, pi)
    }

    fun scheduleWeekly(c: Context) {
        val p = c.getSharedPreferences("a", 0)
        val pi = PendingIntent.getBroadcast(c, 3, Intent(c, WeeklyReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        if (!p.getBoolean("wk", true)) { c.getSystemService(AlarmManager::class.java).cancel(pi); return }
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, (Calendar.SUNDAY - get(Calendar.DAY_OF_WEEK) + 7) % 7)
            set(Calendar.HOUR_OF_DAY, 19); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 7)
        }
        setAlarm(c, cal.timeInMillis, pi)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = c.getSharedPreferences("a", 0)
        if (p.getBoolean("rem", true)) {
            val n = Calendar.getInstance()
            val due = (p.getInt("mask", 0) shr ((n.get(Calendar.DAY_OF_WEEK) + 5) % 7)) and 1 == 1
            val open = if (p.getString("date", "") == Notifier.today()) p.getInt("pending", 0) > 0 else due
            if (open) Notifier.show(c, p.getString("msg", "Jonas du elendiger looser")!!)
        }
        Notifier.schedule(c)
    }
}

class WeeklyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = c.getSharedPreferences("a", 0)
        if (p.getBoolean("wk", true)) {
            val t = p.getString("wktext", "") ?: ""
            val fresh = p.getString("wkdate", "") == Notifier.today() && t.isNotEmpty()
            Notifier.showWeekly(c, if (fresh) t else "Deine Wochenbilanz ist fertig. Öffne die App.")
        }
        Notifier.scheduleWeekly(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Notifier.schedule(c); Notifier.scheduleWeekly(c) }
}
