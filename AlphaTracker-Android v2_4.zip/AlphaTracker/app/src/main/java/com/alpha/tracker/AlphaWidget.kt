package com.alpha.tracker

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class AlphaWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(c))
    }

    companion object {
        fun build(c: Context): RemoteViews {
            val p = c.getSharedPreferences("a", 0)
            val v = RemoteViews(c.packageName, R.layout.widget)
            val fresh = p.getString("date", "") == Notifier.today()
            val total = p.getInt("wtotal", 0); val done = p.getInt("wdone", 0)
            v.setTextViewText(R.id.w_count, if (fresh) "$done/$total" else "–")
            v.setProgressBar(R.id.w_bar, 100, if (fresh && total > 0) done * 100 / total else 0, false)
            v.setTextViewText(R.id.w_list, when {
                !fresh -> "Neuer Tag. Öffne die App."
                total == 0 -> "Heute keine Habits."
                done == total -> "Alles erledigt. Stark."
                else -> p.getString("wopen", "") ?: ""
            })
            v.setTextViewText(R.id.w_streak, if (fresh) "🔥 " + p.getInt("wstreak", 0) else "")
            v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 2,
                Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            return v
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, AlphaWidget::class.java))) m.updateAppWidget(id, build(c))
        }
    }
}
