package com.alpha.tracker

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0B0C0E"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) { openWeek() }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        askPerm()
    }

    private fun openWeek() {
        if (intent?.getBooleanExtra("week", false) == true) {
            web.evaluateJavascript("setView('week')", null)
            intent.removeExtra("week")
        }
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); setIntent(i); openWeek() }

    private fun askPerm() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    inner class Bridge {
        private val prefs get() = getSharedPreferences("a", 0)

        @JavascriptInterface fun vibrate(p: String) {
            val a = JSONArray(p)
            val t = LongArray(a.length() + 1) { if (it == 0) 0L else a.getLong(it - 1) }
            getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createWaveform(t, -1))
        }
        @JavascriptInterface fun sync(rem: Boolean, time: String, msg: String, pending: Int, date: String, mask: Int) {
            prefs.edit().putBoolean("rem", rem).putString("time", time).putString("msg", msg)
                .putInt("pending", pending).putString("date", date).putInt("mask", mask).apply()
            Notifier.schedule(applicationContext)
        }
        @JavascriptInterface fun widget(total: Int, done: Int, open: String, streak: Int) {
            prefs.edit().putInt("wtotal", total).putInt("wdone", done).putString("wopen", open).putInt("wstreak", streak).apply()
            AlphaWidget.refresh(applicationContext)
        }
        @JavascriptInterface fun weekly(on: Boolean, text: String, date: String) {
            prefs.edit().putBoolean("wk", on).putString("wktext", text).putString("wkdate", date).apply()
            Notifier.scheduleWeekly(applicationContext)
        }
        @JavascriptInterface fun test(msg: String) {
            runOnUiThread { askPerm() }
            Notifier.show(applicationContext, msg)
        }
        @JavascriptInterface fun testWeekly(text: String) {
            runOnUiThread { askPerm() }
            Notifier.showWeekly(applicationContext, text)
        }
    }
}
