plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{
 namespace="com.alpha.tracker";compileSdk=34
 defaultConfig{applicationId="com.alpha.tracker";minSdk=26;targetSdk=34;versionCode=2;versionName="1.1"}
 signingConfigs{getByName("debug"){storeFile=rootProject.file("alpha.keystore");storePassword="android";keyAlias="androiddebugkey";keyPassword="android"}}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 kotlinOptions{jvmTarget="17"}
}
