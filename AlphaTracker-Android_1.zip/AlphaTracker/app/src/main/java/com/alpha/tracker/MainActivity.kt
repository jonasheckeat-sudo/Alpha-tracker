package com.alpha.tracker

import android.Manifest
import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0B0C0E"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        askPerm()
    }

    private fun askPerm() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    inner class Bridge {
        @JavascriptInterface fun vibrate(p: String) {
            val a = JSONArray(p)
            val t = LongArray(a.length() + 1) { if (it == 0) 0L else a.getLong(it - 1) }
            getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createWaveform(t, -1))
        }
        @JavascriptInterface fun sync(rem: Boolean, time: String, msg: String, pending: Int, date: String, mask: Int) {
            getSharedPreferences("a", 0).edit()
                .putBoolean("rem", rem).putString("time", time).putString("msg", msg)
                .putInt("pending", pending).putString("date", date).putInt("mask", mask).apply()
            Notifier.schedule(applicationContext)
        }
        @JavascriptInterface fun test(msg: String) {
            runOnUiThread { askPerm() }
            Notifier.show(applicationContext, msg)
        }
    }
}
